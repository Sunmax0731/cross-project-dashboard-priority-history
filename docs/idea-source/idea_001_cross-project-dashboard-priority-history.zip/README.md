# 横断ダッシュボード・履歴・優先度管理 開発パック

| 項目 | 内容 |
| --- | --- |
| 領域 | ProjectManagement |
| No. | 1 |
| 分野 | 横断状態管理 |
| アイデア | 横断ダッシュボード・履歴・優先度管理 |
| リポジトリ名 | cross-project-dashboard-priority-history |
| 概要 | 複数プロジェクトの状態、履歴、依存関係、未完了Issue、停滞PR、次に渡せるエージェント作業を横断表示する。 |
| 課題 | 複数プロジェクトを進めると、どれが次に進められるか、何が放置されているか分かりにくい。 |
| 類似サービス・アプリ | GitHub Projects, Linear, Jira, Codex, Cursor |
| 差別化ポイント | 履歴と依存関係を見ながら、エージェントに渡せる粒度の次タスクまで並べ替える。 |

## 目的

このZIPには、`ProjectManagement` 領域のアイデア `横断ダッシュボード・履歴・優先度管理` を実装可能なプロジェクトへ落とし込むための初期ドキュメントが含まれています。

## 含まれるファイル

- START_PROMPT.md
- README.md
- 01_REQUIREMENTS.md
- 02_SPECIFICATION.md
- 03_DESIGN.md
- 04_IMPLEMENTATION_PLAN.md
- 05_TEST_PLAN.md
- 06_RELEASE_CHECKLIST.md
- metadata.json

## 使い方

1. Codexまたは他のコーディングエージェントへの最初のプロンプトとして `START_PROMPT.md` を使用する。
2. 実装前に要件、仕様、設計を確認する。
3. MVPを実装し、テスト計画に沿って検証する。
